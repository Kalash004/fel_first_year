#define INPUT_ERR_CODE 100
#define INPUT_TEXTS_DIFFERENT_SIZE_CODE 101
#define MALLOC_ERROR 102
#define INITIAL_BUFFER_SIZE 10

// ----------------- Error handling -------------------------------------
#ifndef STDIOH
#define STDIOH
#include <stdio.h>
#endif

#ifndef STDLIBH
#define STDLIBH
#include <stdlib.h>
#endif

#ifndef STRINGH
#define STRINGH
#include <string.h>
#endif

#ifndef bool
#ifndef TRUE
#define TRUE 1
#define FALSE 0
#endif
#endif

typedef struct
{
    int code;
    char *message;
} SError;
typedef enum
{
    UNKNOWN_ERROR_CODE,
    INPUT_ERR,
    INPUT_TEXT_DIFF_SIZE_ERR,
    END
} EError_codes;
SError errors[] = {
    {.code = -1, .message = "Error: Unknown error code: %d"},
    {.code = INPUT_ERR_CODE, .message = "Error: Chybny vstup!"},
    {.code = INPUT_TEXTS_DIFFERENT_SIZE_CODE, .message = "Error: Chybna delka vstupu!"},
    {.code = MALLOC_ERROR, .message = "Error: Malloc error"}};
void handle_fatal_error(int code);
void handle_non_fatal_error(int code);
void print_error_message(int code);
void get_error_code_to_message(int code, char buffer[], unsigned int buffer_size);
/// @brief Same as handle_non_fatal_error but exits the program at the end
/// @param code Error code number
void handle_fatal_error(int code)
{
    print_error_message(code);
    exit(code);
}
/// @brief Finds error code, and prints it
/// @param code Error code number
void handle_non_fatal_error(int code)
{
    print_error_message(code);
}
/// @brief Prints error message from char *error_messages[]
/// @param code Error code number
void print_error_message(int code)
{
    char buffer[100];
    get_error_code_to_message(code, &buffer[0], 100);
    fprintf(stderr, "%s\n", buffer);
}
/// @brief Goes thru SError errors[] and finds error by code. If doesnt exist returns Unknown error code
/// @param code int: Error code number
/// @param buffer char[]: Buffer to place message to
/// @param buffer_size int: Size of the buffer
void get_error_code_to_message(int code, char buffer[], unsigned int buffer_size)
{
    SError error;
    for (int i = 0; i < END; ++i)
    {
        error = errors[i];
        if (error.code == code)
        {
            snprintf(buffer, buffer_size, "%s", error.message);
            return;
        }
    }
    error = errors[UNKNOWN_ERROR_CODE];
    snprintf(buffer, buffer_size, error.message, code);
}
// ----------------- Error handling -------------------------------------
#include <ctype.h>
#include <stdbool.h>

char alphabet[] = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'};

typedef struct
{
    int x;
    int y;
} Vector2D;

int *read_input_ciphered(size_t *length);

int *read_input_partial_deciphered(size_t *length);

int *read_unknown_length_input(size_t *length);

int get_char_alphabet_index_Representation(char c);

void *my_malloc(size_t size);

void *my_realloc(void *source, size_t size);

int validate_same_length(size_t ciphered_len, size_t partial_len);

char *handle_decipher(int *ciphered, int *partial, size_t len);

char *decipher(int shift, int *ciphered, size_t str_len);

int get_shift(int *ciphered, int *partial, size_t len);

int increase_count_of_occurrences(Vector2D *vecs, int shift, size_t len);

void zero_out_vectors(Vector2D *vecs, size_t len);

int main(void)
{
    size_t ciphered_len = 0;
    int *ciphered = read_input_ciphered(&ciphered_len);
    size_t partial_len = 0;
    int *partial_deciphered = read_input_partial_deciphered(&partial_len);
    if (!validate_same_length(ciphered_len, partial_len))
    {
        free(ciphered);
        free(partial_deciphered);
        handle_fatal_error(INPUT_TEXTS_DIFFERENT_SIZE_CODE);
    }

    char *truly_deciphered = handle_decipher(ciphered, partial_deciphered, ciphered_len);
    printf("%s\n", truly_deciphered);
    free(ciphered);
    free(partial_deciphered);
    free(truly_deciphered);
}

int *read_input_ciphered(size_t *length)
{
    return read_unknown_length_input(length);
}

int *read_input_partial_deciphered(size_t *length)
{
    return read_unknown_length_input(length);
}

int *read_unknown_length_input(size_t *length)
{
    size_t buffer_size = INITIAL_BUFFER_SIZE;
    size_t current_cell = 0;
    int *buffer = my_malloc(buffer_size * sizeof(int));
    char last_char;
    do
    {
        // get char
        last_char = getc(stdin);
        if (last_char == '\n')
            break;
        if (!isalpha(last_char))
            handle_fatal_error(INPUT_ERR_CODE);

        int index_repr = get_char_alphabet_index_Representation(last_char); // get array representation
        // check buffer is big enough
        if (current_cell > buffer_size - 2)
        {
            buffer_size += 100;
            buffer = my_realloc(buffer, buffer_size * sizeof(int));
        }
        buffer[current_cell] = index_repr;
        ++current_cell;
    } while (last_char != '\n');
    if (current_cell == 0)
    {
        // TODO: handle no input
    }
    *length = current_cell;
    return buffer;
}

int get_char_alphabet_index_Representation(char c)
{
    if (c >= 'a')
    {
        return (int)c - 'a' + 26;
    }
    return (int)c - 'A';
}

void *my_malloc(size_t size)
{
    void *temp = malloc(size);
    if (temp == NULL)
    {
        handle_fatal_error(MALLOC_ERROR);
    }
    return temp;
}

void *my_realloc(void *source, size_t size)
{
    void *temp = realloc(source, size);
    if (temp == NULL)
    {
        free(source); // possible data loss
        handle_fatal_error(MALLOC_ERROR);
    }
    return temp;
}

int validate_same_length(size_t ciphered_len, size_t partial_len)
{
    if (ciphered_len != partial_len)
        return 0;
    return 1;
}

char *handle_decipher(int *ciphered, int *partial, size_t len)
{
    int shift = get_shift(ciphered, partial, len);
    char *temp = decipher(shift, ciphered, len);
    return temp;
}

char *decipher(int shift, int *ciphered, size_t str_len)
{

    char *temp = my_malloc((str_len + 1) * sizeof(char));
    char c;
    size_t i = 0;
    do
    {
        if ((int)ciphered[i] + shift > 51)
        {
            shift -= 52;
        }
        else if ((int)ciphered[i] + shift < 0)
        {
            shift += 52;
        }
        c = alphabet[ciphered[i] + shift];
        temp[i] = c;
        ++i;
    } while (i < str_len);
    temp[i] = '\0';
    return temp;
}

int get_shift(int *ciphered, int *partial, size_t len)
{
    // Getting all possible shifts
    int ciphered_c;
    int partial_c;
    size_t i = 0;
    size_t vecs_buffer_size = INITIAL_BUFFER_SIZE;
    size_t used_vecs = 0;
    Vector2D *vecs = my_malloc(vecs_buffer_size * sizeof(Vector2D));
    zero_out_vectors(vecs, vecs_buffer_size);
    int shift = 0;
    do
    {
        ciphered_c = ciphered[i];
        partial_c = partial[i];
        shift = partial_c - ciphered_c;
        if (!increase_count_of_occurrences(vecs, shift, used_vecs))
        {
            if (used_vecs > vecs_buffer_size - 3)
            {
                vecs_buffer_size += 5;
                vecs = my_realloc(vecs, vecs_buffer_size * sizeof(Vector2D));
            }
            Vector2D vec = {.x = shift, .y = 1}; // .y = count of occurrences .x = shift
            vecs[used_vecs] = vec;
            ++used_vecs;
        }
        ++i;
    } while (i < len);

    // Finding most occurred shift
    Vector2D vec;
    int largest_occur = 0;
    int target_shift = 0;
    size_t j = 0;
    do
    {
        vec = vecs[j];
        if (vec.y > largest_occur)
        {
            largest_occur = vec.y;
            target_shift = vec.x;
        }
        ++j;
    } while (j < used_vecs);
    free(vecs);
    return target_shift;
}

int increase_count_of_occurrences(Vector2D *vecs, int shift, size_t len)
{
    Vector2D vec;
    size_t i = 0;
    do
    {
        vec = vecs[i];
        if (vec.x == shift && vec.y != -1)
        {
            vecs[i] = (Vector2D){.x = vec.x, .y = vec.y + 1};
            return 1;
        }
        ++i;
    } while (i < len);
    return 0;
}

void zero_out_vectors(Vector2D *vecs, size_t len)
{
    for (size_t i = 0; i < len; ++i)
    {

        vecs[i] = (Vector2D){.x = -1, .y = -1};
    }
    vecs[len - 1] = (Vector2D){.x = -1, .y = -1};
}
